import dropbox

from picamera import PiCamera
from datatime import datetime
from time import sleep
from socket import *
from time import ctime
import smtplib
import RPi.GPIO as GPIO
import time
import os
import sys

cur_X = 0
MotionPin = 16
TouchPin = 24
GLEDPin = 27
RLEDPin = 25
BuzzerPin = 17
ServoPin = 22
pwmHz = 50

P = PiCamera()
P.resolution = (1024, 768)
P.framerate = 30
h264_video = ".h264"
mp4_video = ".mp4"

ctrCmd = ['Left', 'Right']
HOST = '192.168.1.13'
PORT = 21567
BUFSIZE = 1024
ADDR = (HOST, PORT)
tcpSerSock = socket(AF_INET, SOCK_STREAM)
tcpSerSock.bind(ADDR)
tcpSerSock.listen(5)


class TransferData:
    def __init__(self, access_token):
        self.access_token = access_token

    def upload_file(self, file_from, file_to):
        dbx = drop_box.Dropbox(self.access_token)
        with open(file_from, 'rb') as f:
            dbx.files_upload(f.read(), file_to)


def setup():
    global servo
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(MotionPin, GPIO.IN)
    GPIO.setup(TouchPin, GPIO.IN)
    GPIO.setup(GLEDPin, GPIO.OUT)
    GPIO.setup(RLEDPin, GPIO.OUT)
    GPIO.setup(BuzzerPin, GPIO.OUT)
    GPIO.output(BuzzerPin, GPIO.LOW)
    GPIO.output(GLEDPin, GPIO.LOW)
    GPIO.output(RLEDPin, GPIO.LOW)
    GPIO.setup(ServoPin, GPIO.OUT)
    servo = GPIO.PWM(ServoPin, pwmHz)
    servo.start(2.5)
    servo.ChangeDutyCycle(2.5)


def Servoleft():
    global cur_X
    cur_X += 2.5
    if cur_X > 12:
        cur_X = 12.5
    servo.ChangeDutyCycle(cur_X)
    time.sleep(1)


def Servoright():
    global cur_X
    cur_X -= 2.5
    if cur_X < 2.5:
        cur_X = 2.5
    servo.ChangeDutyCycle(cur_X)
    time.sleep(1)


def loopCamera():
    while True:
        GPIO.output(GLEDPin, GPIO.HIGH)
        if GPIO.input(MotionPin):
            GPIO.output(GLEDPin, GPIO.LOW)
            GPIO.output(BuzzerPin, GPIO.HIGH)
            GPIO.output(RLEDPin, GPIO.HIGH)
            print("Motion...")
            # camera warm-up time
            P.capture('movement.jpg')
            video_name = datetime.now().strftime("%m-%d-%Y_%H.%M.%S")
            # P.start_recording('/home/pi/Desktop/video.h264')
            P.start_recording(video_name + h264_video)
            time.sleep(11)
            P.stop_recording()
            GPIO.output(BuzzerPin, GPIO.LOW)
            GPIO.output(RLEDPin, GPIO.LOW)
            GPIO.output(GLEDPin, GPIO.HIGH)
            os.system("MP4Box -add " + video_name + h264_video + " " + video_name + mp4_video)
            os.system("rm " + video_name + h264_video)
            footage = video_name + mp4_video

            # email sending
            access_token = 'sl.AbBC_OPTeLuvSCxg9giY2SdVjolrDe4l_meIcqYpaUNjJgIgP-DxIw4fcfgJBwDRylRBtSLgjHLFXRKT_HSWgGaLCCejPoR6scId8-QcSHTxIQqfc8lAj_7765QUwcPFphcXHutc'
            transferData = TransferData(access_token)

            file_from = footage
            file_to = '/home/pi/Desktop/Test/' + footage
            transferData.upload_file(file_from, file_to)


def loopServo():
    while True:
        print 'Waiting for connection'
        tcpCliSock, addr = tcpSerSock.accept()
        print '...connected from :', addr
        try:
            while True:
                data = ''
                data = tcpCliSock.recv(BUFSIZE)
                if not data:
                    break
                if data == ctrCmd[0]:
                    Servoleft()
                    print 'Increase: ', cur_X
                if data == ctrCmd[1]:
                    Servoright()
                    print 'Decrease: ', cur_X
        except KeyboardInterrupt:
            close()
            GPIO.cleanup()


def close():
    servo.stop()


def destroy():
    GPIO.cleanup()
