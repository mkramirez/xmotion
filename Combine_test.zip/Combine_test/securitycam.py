import security_setup
import threading

if __name__ == '__main__':
    security_setup.setup()
    try:
        thread1 = threading.Thread(target=security_setup.loopCamera())
        thread1.daemon = True
        thread1.start()

        thread2 = threading.Thread(target=security_setup.loopServo())
        thread2.daemon = True
        thread2.start()
    except (KeyboardInterrupt, SystemExit):
        security_setup.destroy()

security_setup.tcpSerSock.close()
