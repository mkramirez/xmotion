package com.example.xmotion;

import android.os.AsyncTask;
import android.util.Log;
import android.view.ContextMenu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import org.w3c.dom.Text;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class servo_control extends AppCompatActivity {
    Button right_button;
    Button left_button;
    TextView ipaddress;
    Socket myAppSocket = null;
    public static String wifiModuleIp = "";
    public static int wifiModulePort = 0;
    public static String CMD = "0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_servo_control);

        right_button = (Button) findViewById(R.id.right_button);
        left_button = (Button) findViewById(R.id.left_button);
        ipaddress = (TextView) findViewById(R.id.ipaddress_text);

        right_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                getIPandPort();
                CMD = "Right";
                Socket_AsyncTask cmd_increase_servo = new Socket_AsyncTask();
                cmd_increase_servo.execute();
            }
        });
        left_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                getIPandPort();
                CMD = "Left";
                Socket_AsyncTask cmd_increase_servo = new Socket_AsyncTask();
                cmd_increase_servo.execute();
            }
        });
    }

    public void getIPandPort() {
        String IPandPort = ipaddress.getText().toString();
        Log.d("MYTEST", "IP String: " + IPandPort);
        String temp[] = IPandPort.split(":");
        wifiModuleIp = temp[0];
        wifiModulePort = Integer.valueOf(temp[1]);
        Log.d("MY TEST", "IP:" + wifiModuleIp);
        Log.d("MY TEST", "PORT:" + wifiModulePort);
    }

    public class Socket_AsyncTask extends AsyncTask<Void,Void,Void> {
        Socket socket;

        @Override
        protected  Void doInBackground(Void... params) {
            try {
                InetAddress inetAddress = InetAddress.getByName(servo_control.wifiModuleIp);
                socket = new java.net.Socket(inetAddress,servo_control.wifiModulePort);
                DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
                dataOutputStream.writeBytes(CMD);
                dataOutputStream.close();
                socket.close();
            } catch (UnknownHostException e) {e.printStackTrace();} catch (IOException e){e.printStackTrace();}
            return null;
        }
    }
}

