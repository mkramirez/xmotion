package com.example.xmotion;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class home_screen extends AppCompatActivity {
    private Button gallery;
    private Button control;
    private Button logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        gallery = (Button) findViewById(R.id.gallery_button);
        gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery_Screen();
            }
        });
        control = (Button) findViewById(R.id.control_button);
        control.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openServo_Control();
            }
        });
        logout = (Button) findViewById(R.id.logout_button);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeHome_Screen();
            }
        });

    }

    public void openGallery_Screen() {
        Intent intent = new Intent(this, gallery_view.class);
        startActivity(intent);
    }

    public void openServo_Control() {
        Intent intent = new Intent(this, servo_control.class);
        startActivity(intent);
    }

    public void closeHome_Screen() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
