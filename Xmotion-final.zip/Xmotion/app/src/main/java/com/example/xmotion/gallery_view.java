package com.example.xmotion;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class gallery_view extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery_view);
    }
}
